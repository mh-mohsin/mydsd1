
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs, 
  orderBy, 
  increment,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../firebase';
import { StudySession, UserProfile } from '../types';

export const createUserProfile = async (uid: string, name: string, email: string) => {
  const userRef = doc(db, 'users', uid);
  await setDoc(userRef, {
    uid,
    name,
    email,
    createdAt: Date.now(),
    totalStudyTime: 0,
    streak: 0,
    dailyGoal: 120,
    role: 'user' // Default role
  });
};

export const getUserProfile = async (uid: string): Promise<UserProfile | null> => {
  const userRef = doc(db, 'users', uid);
  const snap = await getDoc(userRef);
  return snap.exists() ? (snap.data() as UserProfile) : null;
};

export const getAllUsers = async (): Promise<UserProfile[]> => {
  const usersRef = collection(db, 'users');
  const snap = await getDocs(usersRef);
  return snap.docs.map(doc => doc.data() as UserProfile);
};

export const addStudySession = async (uid: string, session: StudySession) => {
  const sessionsRef = collection(db, 'users', uid, 'sessions');
  const userRef = doc(db, 'users', uid);
  
  await addDoc(sessionsRef, {
    ...session,
    createdAt: serverTimestamp()
  });

  await updateDoc(userRef, {
    totalStudyTime: increment(session.duration)
  });
};

export const getSessionsByDateRange = async (uid: string, startDate: string, endDate: string): Promise<StudySession[]> => {
  const sessionsRef = collection(db, 'users', uid, 'sessions');
  const q = query(
    sessionsRef, 
    where('date', '>=', startDate), 
    where('date', '<=', endDate)
  );
  
  const querySnapshot = await getDocs(q);
  const sessions = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as StudySession));

  return sessions.sort((a, b) => {
    if (a.date !== b.date) {
      return b.date.localeCompare(a.date);
    }
    return b.startTime.localeCompare(a.startTime);
  });
};

export const getAllSessions = async (uid: string): Promise<StudySession[]> => {
  const sessionsRef = collection(db, 'users', uid, 'sessions');
  const q = query(sessionsRef, orderBy('date', 'desc'));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as StudySession));
};

export const updateUserGoal = async (uid: string, goal: number) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { dailyGoal: goal });
};
