
import React, { useState, useEffect } from 'react';
import { NavLink, useNavigate, useParams, useLocation } from 'react-router-dom';
import { auth } from '../firebase';
import { signOut } from 'firebase/auth';
import { getUserProfile } from '../services/dbService';
import { 
  LayoutDashboard, 
  Calendar, 
  BarChart2, 
  FileText, 
  User, 
  LogOut, 
  Menu, 
  BookOpen,
  ShieldCheck,
  ChevronLeft
} from 'lucide-react';
import { UserProfile } from '../types';

interface LayoutProps {
  children?: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [currentUserProfile, setCurrentUserProfile] = useState<UserProfile | null>(null);
  const { uid } = useParams(); // target user ID if in admin mode
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProfile = async () => {
      if (auth.currentUser) {
        const p = await getUserProfile(auth.currentUser.uid);
        setCurrentUserProfile(p);
      }
    };
    fetchProfile();
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const isAdminView = location.pathname.includes('/admin/user/');
  const isAdmin = currentUserProfile?.role === 'admin';

  const baseNavItems = [
    { name: 'ড্যাশবোর্ড', path: '', icon: <LayoutDashboard size={20} /> },
    { name: 'ক্যালেন্ডার', path: '/calendar', icon: <Calendar size={20} /> },
    { name: 'বিশ্লেষণ', path: '/analysis', icon: <BarChart2 size={20} /> },
    { name: 'রিপোর্ট', path: '/reports', icon: <FileText size={20} /> },
    { name: 'প্রোফাইল', path: '/profile', icon: <User size={20} /> },
  ];

  const getPath = (itemPath: string) => {
    if (isAdminView && uid) {
      return `/admin/user/${uid}${itemPath || '/dashboard'}`;
    }
    return itemPath || '/';
  };

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-100 overflow-hidden">
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/70 z-40 md:hidden backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside className={`
        fixed inset-y-0 left-0 z-50 w-72 bg-slate-900 border-r border-slate-800 
        transform transition-transform duration-300 ease-in-out md:translate-x-0
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        h-screen flex-shrink-0
      `}>
        <div className="flex flex-col h-full overflow-y-auto no-scrollbar">
          <div className="p-8 flex items-center gap-3">
            <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
              <BookOpen size={24} />
            </div>
            <span className="text-xl font-bold tracking-tight bg-gradient-to-r from-white to-slate-400 bg-clip-text text-transparent">স্টাডি ডায়েরি</span>
          </div>

          {isAdminView && (
            <div className="px-6 mb-4">
              <button 
                onClick={() => navigate('/admin')}
                className="w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-indigo-400 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all"
              >
                <ChevronLeft size={16} /> অ্যাডমিন প্যানেল
              </button>
              <div className="mt-4 p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
                 <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1 text-center">ইউজার ভিউ মোড</p>
                 <p className="text-xs text-white text-center truncate font-bold">আইডি: {uid}</p>
              </div>
            </div>
          )}

          <nav className="flex-1 px-4 space-y-2">
            {isAdmin && !isAdminView && (
              <NavLink
                to="/admin"
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => `
                  flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all duration-200 mb-6
                  ${isActive 
                    ? 'bg-amber-500 text-white shadow-lg shadow-amber-500/20 font-bold' 
                    : 'bg-slate-800/50 text-amber-500 hover:bg-slate-800 hover:text-amber-400'}
                `}
              >
                <ShieldCheck size={20} />
                <span className="text-[15px]">অ্যাডমিন প্যানেল</span>
              </NavLink>
            )}

            {baseNavItems.map((item) => (
              <NavLink
                key={item.path}
                to={getPath(item.path)}
                end={item.path === ''}
                onClick={() => setIsOpen(false)}
                className={({ isActive }) => `
                  flex items-center gap-4 px-4 py-3.5 rounded-xl transition-all duration-200
                  ${isActive 
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 font-medium' 
                    : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'}
                `}
              >
                {item.icon}
                <span className="text-[15px]">{item.name}</span>
              </NavLink>
            ))}
          </nav>

          <div className="p-6 border-t border-slate-800">
            <button 
              onClick={handleLogout}
              className="flex w-full items-center gap-4 px-4 py-3 rounded-xl text-rose-400 hover:bg-rose-500/10 transition-colors"
            >
              <LogOut size={20} />
              <span className="text-[15px]">লগআউট</span>
            </button>
          </div>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 md:ml-72 h-screen overflow-hidden">
        <header className="h-20 border-b border-slate-800 bg-slate-900/50 backdrop-blur-md flex items-center justify-between px-6 md:px-10 flex-shrink-0 sticky top-0 z-30">
          <button 
            className="md:hidden text-slate-400"
            onClick={() => setIsOpen(true)}
          >
            <Menu size={24} />
          </button>
          <div className="hidden md:block">
             <h2 className="text-sm font-medium text-slate-500 uppercase tracking-widest">
               {isAdminView ? 'ইউজার স্টাডি প্রোফাইল পর্যবেক্ষণ' : 'আমার পড়াশোনা'}
             </h2>
          </div>
          <div className="flex items-center gap-4">
             <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-slate-200 leading-tight">
                  {isAdminView ? 'অ্যাডমিন ভিউ' : auth.currentUser?.displayName}
                </p>
                <p className="text-[11px] text-slate-500">{isAdmin ? 'অ্যাডমিনিস্ট্রেটর' : 'অনলাইন'}</p>
             </div>
             <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-white font-bold shadow-lg">
               {isAdmin ? 'A' : (auth.currentUser?.displayName?.charAt(0) || 'U')}
             </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-6 md:p-10 bg-slate-950">
          <div className="max-w-7xl mx-auto">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Layout;
