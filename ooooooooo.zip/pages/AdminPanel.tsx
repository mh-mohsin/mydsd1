
import React, { useState, useEffect } from 'react';
import { getAllUsers } from '../services/dbService';
import { UserProfile } from '../types';
import { Link } from 'react-router-dom';
import { Users, Search, ExternalLink, Mail, Clock, Calendar } from 'lucide-react';
import { formatDurationBn } from './Dashboard';

const AdminPanel: React.FC = () => {
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    const fetchUsers = async () => {
      const data = await getAllUsers();
      setUsers(data);
      setLoading(false);
    };
    fetchUsers();
  }, []);

  const filteredUsers = users.filter(u => 
    u.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    u.email.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
      <div className="w-10 h-10 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
      <p className="text-slate-400 font-medium">ইউজার লিস্ট লোড হচ্ছে...</p>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-white flex items-center gap-3">
            <Users size={32} className="text-indigo-500" /> অ্যাডমিন প্যানেল
          </h1>
          <p className="text-slate-500 mt-1">সব ইউজারের পড়াশোনা পর্যবেক্ষণ করুন</p>
        </div>

        <div className="relative w-full md:w-80">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
          <input 
            type="text" 
            placeholder="নাম বা ইমেইল দিয়ে খুঁজুন..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-2xl pl-12 pr-6 py-3 text-sm text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredUsers.map(user => (
          <div key={user.uid} className="bg-slate-900 p-6 rounded-[2rem] border border-slate-800 shadow-xl hover:border-indigo-500/30 transition-all group flex flex-col">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center text-white text-xl font-black shadow-lg">
                {user.name.charAt(0)}
              </div>
              <div className="min-w-0">
                <h3 className="text-lg font-bold text-white truncate">{user.name}</h3>
                <p className="text-xs text-slate-500 truncate flex items-center gap-1">
                  <Mail size={12} /> {user.email}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/50">
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1 flex items-center gap-1">
                  <Clock size={10} /> মোট সময়
                </p>
                <p className="text-xs font-bold text-slate-300">{formatDurationBn(user.totalStudyTime)}</p>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/50">
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mb-1 flex items-center gap-1">
                  <Calendar size={10} /> স্ট্রিক
                </p>
                <p className="text-xs font-bold text-slate-300">{user.streak} দিন</p>
              </div>
            </div>

            <Link 
              to={`/admin/user/${user.uid}/dashboard`}
              className="mt-auto w-full flex items-center justify-center gap-2 bg-slate-800 hover:bg-indigo-600 text-white py-3 rounded-xl font-bold transition-all active:scale-95 text-sm"
            >
              ভিউ ডাটা <ExternalLink size={16} />
            </Link>
          </div>
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <div className="py-20 text-center bg-slate-900/50 border border-slate-800 rounded-[2.5rem]">
           <Users size={48} className="mx-auto text-slate-700 mb-4" />
           <p className="text-slate-500 font-bold">কোনো ইউজার খুঁজে পাওয়া যায়নি</p>
        </div>
      )}
    </div>
  );
};

export default AdminPanel;
