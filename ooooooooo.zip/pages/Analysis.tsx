
import React, { useState, useEffect, useMemo } from 'react';
import { useParams } from 'react-router-dom';
import { auth } from '../firebase';
import { getAllSessions } from '../services/dbService';
import { StudySession } from '../types';
import { formatDurationBn } from './Dashboard';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell
} from 'recharts';
import { format, isWithinInterval, endOfDay, differenceInDays } from 'date-fns';
import { bn } from 'date-fns/locale';
import { TrendingUp, BookOpen, Target, Clock, List, FileText, Hash } from 'lucide-react';
import { jsPDF } from "jspdf";
import autoTable from 'jspdf-autotable';

type FilterType = 'week' | 'month' | '3month' | 'custom';

const formatDurationEng = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h > 0 && m > 0) return `${h} Hrs ${m} Mins`;
  if (h > 0) return `${h} Hrs`;
  return `${m} Mins`;
};

const Analysis: React.FC = () => {
  const { uid: targetUid } = useParams();
  const uid = targetUid || auth.currentUser?.uid;

  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<FilterType>('week');
  const [customRange, setCustomRange] = useState({
    start: format(new Date(Date.now() - 7 * 86400000), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd')
  });

  useEffect(() => {
    const fetchData = async () => {
      if (!uid) return;
      const data = await getAllSessions(uid);
      setSessions(data);
      setLoading(false);
    };
    fetchData();
  }, [uid]);

  const { filteredSessions, dateRangeLabel, daysCount } = useMemo(() => {
    let start = new Date();
    let end = new Date();
    let label = '';

    if (filterType === 'week') {
      start.setDate(start.getDate() - 6);
      label = 'Last 7 Days';
    } else if (filterType === 'month') {
      start.setDate(start.getDate() - 29);
      label = 'Last 30 Days';
    } else if (filterType === '3month') {
      start.setDate(start.getDate() - 89);
      label = 'Last 90 Days';
    } else {
      start = new Date(customRange.start + 'T00:00:00');
      end = new Date(customRange.end + 'T00:00:00');
      label = 'Custom Range';
    }

    const filtered = sessions.filter(s => {
      const sessionDate = new Date(s.date + 'T00:00:00');
      const startOfDayNative = new Date(start);
      startOfDayNative.setHours(0, 0, 0, 0);
      return isWithinInterval(sessionDate, { 
        start: startOfDayNative, 
        end: endOfDay(end) 
      });
    });

    const diff = Math.max(1, differenceInDays(end, start) + 1);
    return { filteredSessions: filtered, dateRangeLabel: label, daysCount: diff };
  }, [sessions, filterType, customRange]);

  const totalTime = filteredSessions.reduce((acc, s) => acc + s.duration, 0);

  const typeData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredSessions.forEach(s => {
      map[s.studyType] = (map[s.studyType] || 0) + s.duration;
    });
    return Object.keys(map).map(name => ({ name, value: map[name] })).sort((a, b) => b.value - a.value);
  }, [filteredSessions]);

  const subjectAnalysis = useMemo(() => {
    const map: Record<string, { duration: number, sessions: number }> = {};
    filteredSessions.forEach(s => {
      if (!map[s.subject]) map[s.subject] = { duration: 0, sessions: 0 };
      map[s.subject].duration += s.duration;
      map[s.subject].sessions += 1;
    });
    return Object.keys(map).map(name => ({
      name, duration: map[name].duration, sessions: map[name].sessions,
      percentage: totalTime > 0 ? (map[name].duration / totalTime) * 100 : 0
    })).sort((a, b) => b.duration - a.duration);
  }, [filteredSessions, totalTime]);

  const trendData = useMemo(() => {
    const plotDays = filterType === 'week' ? 7 : 30;
    return Array.from({ length: plotDays }).map((_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - ((plotDays - 1) - i));
      const dateStr = format(date, 'yyyy-MM-dd');
      const daySessions = sessions.filter(s => s.date === dateStr);
      return {
        name: format(date, 'EEE', { locale: bn }),
        minutes: daySessions.reduce((acc, s) => acc + s.duration, 0)
      };
    });
  }, [sessions, filterType]);

  const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#f97316', '#10b981', '#64748b'];

  if (loading) return (
    <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
      <div className="w-10 h-10 border-4 border-indigo-500 rounded-full animate-spin"></div>
      <p className="text-slate-400">বিশ্লেষণ প্রস্তুত হচ্ছে...</p>
    </div>
  );

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fadeIn">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-white">পড়াশোনা বিশ্লেষণ</h1>
          <p className="text-slate-500 mt-1">{targetUid ? 'ইউজারের অগ্রগতির বিস্তারিত চিত্র' : 'আপনার শেখার অগ্রগতির বিস্তারিত চিত্র'}</p>
        </div>

        <div className="flex flex-wrap gap-3">
          <div className="bg-slate-900/50 p-2 rounded-2xl border border-slate-800">
            {(['week', 'month', '3month'] as FilterType[]).map((t) => (
              <button key={t} onClick={() => setFilterType(t)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${filterType === t ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400'}`}
              >
                {t === 'week' ? '৭ দিন' : t === 'month' ? '৩০ দিন' : '৯০ দিন'}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 flex items-center gap-4">
          <Clock size={24} className="text-indigo-400" />
          <div><p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">মোট সময়</p><p className="text-xl font-black text-white">{formatDurationBn(totalTime)}</p></div>
        </div>
        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 flex items-center gap-4">
          <Target size={24} className="text-purple-400" />
          <div><p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">গড় সেশন</p><p className="text-xl font-black text-white">{filteredSessions.length ? formatDurationBn(Math.round(totalTime / filteredSessions.length)) : '০'}</p></div>
        </div>
        <div className="bg-slate-900/50 p-6 rounded-3xl border border-slate-800 flex items-center gap-4">
          <BookOpen size={24} className="text-emerald-400" />
          <div><p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">মোট সেশন</p><p className="text-xl font-black text-white">{filteredSessions.length}টি</p></div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-slate-900/50 p-8 rounded-3xl border border-slate-800 h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={trendData}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1e293b" />
              <XAxis dataKey="name" tick={{fill: '#64748b', fontSize: 10}} />
              <YAxis tick={{fill: '#64748b', fontSize: 10}} />
              <Tooltip />
              <Area type="monotone" dataKey="minutes" stroke="#6366f1" fill="#6366f133" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-slate-900/50 p-8 rounded-3xl border border-slate-800">
          <h3 className="text-lg font-bold mb-8 text-white">ধরণ অনুযায়ী বণ্টন</h3>
          <div className="h-60">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={typeData} innerRadius={60} outerRadius={80} paddingAngle={5} dataKey="value">
                  {typeData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analysis;
