
import React, { useState, useEffect } from 'react';
import { auth } from '../firebase';
import { getUserProfile, updateUserGoal } from '../services/dbService';
import { UserProfile } from '../types';
import { formatDurationBn } from './Dashboard';
import { format } from 'date-fns';
import { Mail, Calendar, Target, Award, Clock } from 'lucide-react';

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [newGoal, setNewGoal] = useState(120);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!auth.currentUser) return;
      const p = await getUserProfile(auth.currentUser.uid);
      if (p) {
        setProfile(p);
        setNewGoal(p.dailyGoal);
      }
    };
    fetchProfile();
  }, []);

  const handleUpdateGoal = async () => {
    if (!auth.currentUser) return;
    setSaving(true);
    await updateUserGoal(auth.currentUser.uid, newGoal);
    setProfile(p => p ? { ...p, dailyGoal: newGoal } : null);
    setSaving(false);
    alert("লক্ষ্য আপডেট হয়েছে!");
  };

  if (!profile) return <div className="p-8 text-center text-slate-500 font-bold">প্রোফাইল লোড হচ্ছে...</div>;

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-fadeIn">
      <div className="flex items-center gap-6 p-8 bg-slate-900 border border-slate-800 rounded-3xl shadow-xl">
        <div className="w-24 h-24 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-3xl flex items-center justify-center text-white text-4xl font-black shadow-lg">
          {profile.name.charAt(0)}
        </div>
        <div>
          <h1 className="text-3xl font-black text-white">{profile.name}</h1>
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 text-slate-500 mt-2 font-medium">
            <span className="flex items-center gap-1.5"><Mail size={16} /> {profile.email}</span>
            <span className="flex items-center gap-1.5"><Calendar size={16} /> সদস্য হয়েছেন: {format(profile.createdAt, 'MMM yyyy')}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
          <h3 className="text-xl font-black mb-6 text-white flex items-center gap-2">
            <Target className="text-indigo-400" />
            লক্ষ্য সেটিং
          </h3>
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-bold text-slate-400 mb-2 uppercase tracking-wide">দৈনিক লক্ষ্য (মিনিট)</label>
              <div className="flex gap-4">
                <input 
                  type="number" 
                  value={newGoal}
                  onChange={e => setNewGoal(parseInt(e.target.value))}
                  className="flex-1 px-5 py-3 rounded-2xl border border-slate-800 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                />
                <button 
                  onClick={handleUpdateGoal}
                  disabled={saving}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-2xl font-black transition-all disabled:opacity-50"
                >
                  আপডেট
                </button>
              </div>
              <p className="mt-3 text-[11px] text-slate-500 font-medium">আপনার প্রতিদিনের পড়ার লক্ষ্য পরিবর্তন করতে পারেন।</p>
            </div>
          </div>
        </div>

        <div className="bg-slate-900 p-8 rounded-3xl border border-slate-800 shadow-xl">
           <h3 className="text-xl font-black mb-6 text-white flex items-center gap-2">
            <Award className="text-yellow-400" />
            অর্জিত মাইলস্টোন
          </h3>
          <div className="space-y-4">
            <StatRow label="মোট পড়ার সময়" value={formatDurationBn(profile.totalStudyTime)} icon={<Clock size={16} />} />
            <StatRow label="বর্তমান স্ট্রিক" value={`${profile.streak} দিন`} icon={<Calendar size={16} />} />
            <StatRow label="লেভেল" value="অন্বেষক" icon={<Award size={16} />} />
          </div>
        </div>
      </div>
    </div>
  );
};

const StatRow = ({ label, value, icon }: { label: string, value: string, icon: React.ReactNode }) => (
  <div className="flex items-center justify-between p-4 bg-slate-950/40 border border-slate-800/50 rounded-2xl">
    <div className="flex items-center gap-3 text-slate-400 font-medium">
      {icon}
      <span>{label}</span>
    </div>
    <span className="font-black text-slate-100">{value}</span>
  </div>
);

export default Profile;
