
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { auth } from '../firebase';
import { getSessionsByDateRange } from '../services/dbService';
import { StudySession } from '../types';
import { formatDurationBn, formatTime12h } from './Dashboard';
import { format, endOfMonth, eachDayOfInterval, isSameMonth, isToday, isSameDay } from 'date-fns';
import { bn } from 'date-fns/locale';
import { ChevronLeft, ChevronRight, Clock, Book, Calendar as CalendarIcon } from 'lucide-react';

const CalendarPage: React.FC = () => {
  const { uid: targetUid } = useParams();
  const uid = targetUid || auth.currentUser?.uid;

  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [sessions, setSessions] = useState<StudySession[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchSessions = async (date: Date) => {
    if (!uid) return;
    setLoading(true);
    const dateStr = format(date, 'yyyy-MM-dd');
    const data = await getSessionsByDateRange(uid, dateStr, dateStr);
    setSessions(data);
    setLoading(false);
  };

  useEffect(() => {
    fetchSessions(selectedDate);
  }, [selectedDate, uid]);

  const startOfMonthNative = new Date(currentMonth.getFullYear(), currentMonth.getMonth(), 1);
  const days = eachDayOfInterval({
    start: startOfMonthNative,
    end: endOfMonth(currentMonth),
  });

  const nextMonth = () => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + 1));
  const prevMonth = () => setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() - 1));

  return (
    <div className="max-w-6xl mx-auto space-y-10 animate-fadeIn">
      <div>
        <h1 className="text-3xl font-black text-white">স্টাডি ক্যালেন্ডার</h1>
        <p className="text-slate-500 mt-1">{targetUid ? 'ইউজারের পড়াশোনার ইতিহাস' : 'আপনার পড়াশোনার ইতিহাস দেখুন তারিখ অনুযায়ী'}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
        <div className="lg:col-span-2 bg-slate-900/50 rounded-3xl p-8 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-10">
            <h2 className="text-xl font-black text-white capitalize">{format(currentMonth, 'MMMM yyyy', {locale: bn})}</h2>
            <div className="flex gap-4">
              <button onClick={prevMonth} className="w-10 h-10 flex items-center justify-center bg-slate-800 rounded-xl"><ChevronLeft/></button>
              <button onClick={nextMonth} className="w-10 h-10 flex items-center justify-center bg-slate-800 rounded-xl"><ChevronRight/></button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-3 text-center">
            {['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি'].map(day => <div key={day} className="text-[10px] font-black text-slate-600 uppercase pb-4">{day}</div>)}
            {Array.from({ length: startOfMonthNative.getDay() }).map((_, i) => <div key={i} className="h-16 md:h-24"></div>)}
            {days.map((day, i) => (
              <button key={i} onClick={() => setSelectedDate(day)}
                className={`h-16 md:h-24 rounded-2xl flex flex-col items-center justify-center transition-all ${isSameDay(day, selectedDate) ? 'bg-indigo-600 text-white shadow-xl scale-[1.05]' : 'hover:bg-slate-800 text-slate-400'}`}
              >
                <span className="text-sm font-bold">{format(day, 'd')}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-slate-900/50 rounded-3xl p-8 border border-slate-800 shadow-xl h-fit">
          <h3 className="font-black text-white mb-8 pb-4 border-b border-slate-800">
            {format(selectedDate, 'd MMMM, yyyy', {locale: bn})}
          </h3>
          {loading ? <div className="py-20 text-center text-slate-600">লোড হচ্ছে...</div> : sessions.length > 0 ? (
            <div className="space-y-4">
              {sessions.map((s, i) => (
                <div key={i} className="p-5 rounded-2xl bg-slate-950/40 border border-slate-800/50">
                  <p className="font-black text-indigo-400 text-[15px]">{s.subject}</p>
                  <p className="text-xs text-slate-500 font-medium mb-3">{s.topic}</p>
                  <div className="flex items-center gap-4 text-[10px] text-slate-600 font-bold uppercase">
                     <span className="flex items-center gap-1"><Clock size={12}/> {formatDurationBn(s.duration)}</span>
                     <span className="flex items-center gap-1"><Book size={12}/> {s.studyType}</span>
                  </div>
                </div>
              ))}
            </div>
          ) : <p className="text-center text-slate-600 py-10">কোনো তথ্য নেই</p>}
        </div>
      </div>
    </div>
  );
};

export default CalendarPage;
