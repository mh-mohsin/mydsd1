
import React, { useState } from 'react';
import { auth } from '../firebase';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { Link, useNavigate } from 'react-router-dom';
import { BookOpen, LogIn, Mail, Lock, Sparkles } from 'lucide-react';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/');
    } catch (err: any) {
      setError("ইমেইল বা পাসওয়ার্ড ভুল হয়েছে। আবার চেষ্টা করুন।");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
      <div className="w-full max-w-md bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-800 overflow-hidden animate-fadeIn relative">
        <div className="absolute top-0 right-0 p-8 text-indigo-500/20">
          <Sparkles size={80} />
        </div>
        <div className="p-10 md:p-14 relative z-10">
          <div className="flex flex-col items-center mb-12">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-2xl shadow-indigo-600/30 mb-6">
              <BookOpen size={32} />
            </div>
            <h1 className="text-2xl font-black text-white text-center">ডিজিটাল স্টাডি ডায়েরি</h1>
            <p className="text-slate-500 mt-2 font-medium">আবার স্বাগতম!</p>
          </div>
          
          {error && (
            <div className="mb-8 p-4 bg-rose-500/10 text-rose-400 text-sm rounded-2xl border border-rose-500/20 text-center font-bold">
              {error}
            </div>
          )}
          
          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">ইমেইল ঠিকানা</label>
              <div className="relative group">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-500 transition-colors" size={20} />
                <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@email.com"
                  className="w-full pl-14 pr-6 py-4 rounded-2xl border border-slate-800 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 outline-none transition-all placeholder:text-slate-800"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">পাসওয়ার্ড</label>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-500 transition-colors" size={20} />
                <input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••"
                  className="w-full pl-14 pr-6 py-4 rounded-2xl border border-slate-800 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 outline-none transition-all placeholder:text-slate-800"
                />
              </div>
            </div>
            
            <button disabled={loading} type="submit" 
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white py-5 rounded-2xl font-black text-lg shadow-2xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-3 disabled:opacity-50 active:scale-95"
            >
              {loading ? "লগইন হচ্ছে..." : <><LogIn size={22} /> লগইন করুন</>}
            </button>
          </form>
          
          <p className="mt-12 text-center text-slate-500 font-bold">
            নতুন ইউজার? <Link to="/signup" className="text-indigo-400 hover:text-indigo-300 transition-colors">অ্যাকাউন্ট তৈরি করুন</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
