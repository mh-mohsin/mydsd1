
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { auth } from '../firebase';
import { addStudySession, getSessionsByDateRange, getUserProfile } from '../services/dbService';
import { StudySession, UserProfile } from '../types';
import { format, differenceInMinutes } from 'date-fns';
import { Plus, Book, Clock, Target, X, Sparkles, LayoutList } from 'lucide-react';

export const formatDurationBn = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h > 0 && m > 0) return `${h} ঘণ্টা ${m} মিনিট`;
  if (h > 0) return `${h} ঘণ্টা`;
  return `${m} মিনিট`;
};

export const formatTime12h = (timeStr: string) => {
  if (!timeStr) return '';
  const [h, m] = timeStr.split(':').map(Number);
  const period = h >= 12 ? 'PM' : 'AM';
  const hours = h % 12 || 12;
  const minutes = m.toString().padStart(2, '0');
  return `${hours}:${minutes} ${period}`;
};

const Dashboard: React.FC = () => {
  const { uid: targetUid } = useParams();
  const uid = targetUid || auth.currentUser?.uid;

  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [todaySessions, setTodaySessions] = useState<StudySession[]>([]);
  const [weeklyData, setWeeklyData] = useState<{ date: string, total: number, count: number }[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const [formData, setFormData] = useState({
    subject: '',
    topic: '',
    studyType: 'Reading' as StudySession['studyType'],
    startTime: format(new Date(), 'HH:mm'),
    endTime: format(new Date(), 'HH:mm'),
    note: ''
  });

  const fetchDashboardData = async () => {
    if (!uid) return;
    try {
      const profile = await getUserProfile(uid);
      setUserProfile(profile);

      const todayStr = format(new Date(), 'yyyy-MM-dd');
      const sessions = await getSessionsByDateRange(uid, todayStr, todayStr);
      setTodaySessions(sessions);

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
      const start = format(sevenDaysAgo, 'yyyy-MM-dd');
      const end = format(new Date(), 'yyyy-MM-dd');
      const allWeekSessions = await getSessionsByDateRange(uid, start, end);
      
      const last7DaysSummary = Array.from({ length: 7 }).map((_, i) => {
        const dayDate = new Date();
        dayDate.setDate(dayDate.getDate() - i);
        const d = format(dayDate, 'yyyy-MM-dd');
        const daySessions = allWeekSessions.filter(s => s.date === d);
        return {
          date: d,
          total: daySessions.reduce((acc, s) => acc + s.duration, 0),
          count: daySessions.length
        };
      });
      setWeeklyData(last7DaysSummary);

    } catch (error) {
      console.error("Error:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, [uid]);

  const totalTimeToday = todaySessions.reduce((acc, s) => acc + s.duration, 0);
  const dailyGoal = userProfile?.dailyGoal || 120;
  const goalProgress = (totalTimeToday / dailyGoal) * 100;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uid) return;

    const start = new Date(`2000-01-01T${formData.startTime}`);
    const end = new Date(`2000-01-01T${formData.endTime}`);
    let duration = differenceInMinutes(end, start);
    if (duration < 0) duration += 1440;

    const newSession: StudySession = {
      date: format(new Date(), 'yyyy-MM-dd'),
      startTime: formData.startTime,
      endTime: formData.endTime,
      subject: formData.subject,
      topic: formData.topic,
      studyType: formData.studyType,
      duration,
      note: formData.note
    };

    try {
      await addStudySession(uid, newSession);
      setIsModalOpen(false);
      setFormData({
        subject: '', topic: '', studyType: 'Reading',
        startTime: format(new Date(), 'HH:mm'), endTime: format(new Date(), 'HH:mm'),
        note: ''
      });
      fetchDashboardData();
    } catch (error) {
      alert("সেশন যোগ করতে সমস্যা হয়েছে: " + error);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center h-[60vh] gap-4">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
        <p className="text-slate-400 animate-pulse font-medium">ড্যাশবোর্ড লোড হচ্ছে...</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-6 animate-fadeIn">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            {targetUid ? `${userProfile?.name} এর ড্যাশবোর্ড` : `স্বাগতম, ${userProfile?.name}!`} 
            <Sparkles className="text-yellow-400" size={20} />
          </h1>
          <p className="text-sm text-slate-400">
            {targetUid ? 'ইউজারের বর্তমান পড়াশোনার অবস্থা পর্যবেক্ষণ করছেন' : 'আজকের পড়াশোনার লক্ষ্য পূরণ করতে প্রস্তুত তো?'}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <StatCard label="আজকের সময়" value={formatDurationBn(totalTimeToday)} icon={<Clock size={18} className="text-blue-400" />} color="blue" />
        <StatCard label="মোট সেশন" value={`${todaySessions.length}টি`} icon={<Book size={18} className="text-purple-400" />} color="purple" />
        <StatCard label="দৈনিক লক্ষ্য" value={formatDurationBn(dailyGoal)} icon={<Target size={18} className="text-emerald-400" />} color="emerald" />
      </div>

      {!targetUid && (
        <div className="flex justify-center">
          <button 
            onClick={() => setIsModalOpen(true)}
            className="w-full md:w-max flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3.5 rounded-xl font-bold shadow-xl shadow-indigo-600/20 transition-all hover:scale-[1.02] active:scale-95"
          >
            <Plus size={20} />
            নতুন সেশন যুক্ত করুন
          </button>
        </div>
      )}

      <div className="bg-slate-900/50 p-6 rounded-2xl border border-slate-800 shadow-xl">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-base font-bold text-white">দৈনিক লক্ষ্য অগ্রগতি</h3>
          </div>
          <span className="text-xl font-black text-indigo-400">{Math.round(Math.min(goalProgress, 100))}%</span>
        </div>
        <div className="w-full bg-slate-800 rounded-full h-3 p-0.5 mb-3 shadow-inner">
          <div 
            className="bg-gradient-to-r from-indigo-600 to-purple-500 h-2 rounded-full transition-all duration-1000 shadow-lg" 
            style={{ width: `${Math.min(goalProgress, 100)}%` }}
          />
        </div>
        <p className="text-xs text-slate-400">
          {goalProgress >= 100 
            ? "🎉 লক্ষ্য অর্জিত হয়েছে।" 
            : `লক্ষ্য পূরণে আরও ${formatDurationBn(Math.max(0, dailyGoal - totalTimeToday))} পড়াশোনা প্রয়োজন।`}
        </p>
      </div>

      <div className="bg-slate-900/50 rounded-2xl border border-slate-800 shadow-xl overflow-hidden">
        <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
          <h3 className="text-base font-bold text-white flex items-center gap-2">
            <LayoutList size={18} className="text-slate-500" /> সাপ্তাহিক অগ্রগতি
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/50">
                <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-500 tracking-wider">তারিখ</th>
                <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-500 tracking-wider">মোট সময়</th>
                <th className="px-6 py-3 text-[10px] font-black uppercase text-slate-500 tracking-wider">সেশন সংখ্যা</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {weeklyData.map((day, idx) => (
                <tr key={idx} className="hover:bg-slate-800/20 transition-colors">
                  <td className="px-6 py-4 text-sm font-bold text-slate-200">{day.date === format(new Date(), 'yyyy-MM-dd') ? 'আজ' : day.date}</td>
                  <td className="px-6 py-4 text-sm text-slate-400 font-medium">{day.total > 0 ? formatDurationBn(day.total) : '০ মিনিট'}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-0.5 rounded-full text-[10px] font-black ${day.count > 0 ? 'bg-indigo-500/10 text-indigo-400' : 'bg-slate-800 text-slate-600'}`}>
                      {day.count} টি সেশন
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && !targetUid && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="bg-slate-900 w-full max-w-xl rounded-2xl shadow-2xl border border-slate-800 overflow-hidden animate-slideUp">
            <div className="p-6 border-b border-slate-800 flex justify-between items-center bg-slate-800/20">
              <h3 className="text-lg font-black text-white">নতুন স্টাডি সেশন</h3>
              <button onClick={() => setIsModalOpen(false)} className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-slate-800 text-slate-400 transition-colors">
                <X size={20} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
               {/* Form Fields Same as Before */}
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wide">বিষয় (Subject)</label>
                  <input required type="text" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} placeholder="যেমন: গণিত"
                    className="w-full px-4 py-3 rounded-xl border border-slate-800 bg-slate-950 text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all" 
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wide">টপিক (Topic)</label>
                  <input required type="text" value={formData.topic} onChange={e => setFormData({...formData, topic: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-800 bg-slate-950 text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wide">শুরুর সময়</label>
                  <input required type="time" value={formData.startTime} onChange={e => setFormData({...formData, startTime: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-800 bg-slate-950 text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all" 
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wide">শেষ সময়</label>
                  <input required type="time" value={formData.endTime} onChange={e => setFormData({...formData, endTime: e.target.value})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-800 bg-slate-950 text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none transition-all" 
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-slate-400 mb-1 uppercase tracking-wide">ধরণ</label>
                  <select value={formData.studyType} onChange={e => setFormData({...formData, studyType: e.target.value as any})}
                    className="w-full px-4 py-3 rounded-xl border border-slate-800 bg-slate-950 text-white text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                  >
                    <option value="Reading">পড়া (Reading)</option>
                    <option value="Video Class">ভিডিও ক্লাস (Video Class)</option>
                    <option value="Practice">প্র্যাকটিস (Practice)</option>
                    <option value="Revision">রিভিশন (Revision)</option>
                    <option value="Group Study">গ্রুপ স্টাডি (Group Study)</option>
                  </select>
                </div>
              </div>
              <button type="submit" className="w-full bg-indigo-600 text-white py-4 rounded-xl font-black">তথ্য সংরক্ষণ করুন</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const StatCard = ({ label, value, icon, color }: { label: string, value: string, icon: React.ReactNode, color: string }) => {
  const colors: Record<string, string> = {
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    purple: 'bg-purple-500/10 text-purple-400 border-purple-500/20',
    emerald: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  };
  return (
    <div className={`p-4 rounded-2xl border bg-slate-900/50 shadow-lg ${colors[color]}`}>
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-slate-950/50">{icon}</div>
        <div>
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-0.5">{label}</p>
          <p className="text-sm font-black text-slate-100">{value}</p>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
