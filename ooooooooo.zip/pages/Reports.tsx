
import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import { auth } from '../firebase';
import { getAllSessions } from '../services/dbService';
import { jsPDF } from "jspdf";
import autoTable from 'jspdf-autotable';
import { FileText, Download, Calendar, Filter, Clock } from 'lucide-react';
import { format, endOfMonth, isWithinInterval } from 'date-fns';
import { StudySession } from '../types';

const formatDurationEng = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  if (h > 0 && m > 0) return `${h} Hr ${m} Min`;
  if (h > 0) return `${h} Hr`;
  return `${m} Min`;
};

const Reports: React.FC = () => {
  const { uid: targetUid } = useParams();
  const uid = targetUid || auth.currentUser?.uid;

  const [generating, setGenerating] = useState(false);
  const [selectedDate, setSelectedDate] = useState(format(new Date(), 'yyyy-MM-dd'));
  const [selectedMonth, setSelectedMonth] = useState(format(new Date(), 'yyyy-MM'));

  const generateReport = async (type: 'day' | 'month' | 'full') => {
    if (!uid) return;
    setGenerating(true);
    try {
      const allSessions = await getAllSessions(uid);
      let filtered = allSessions;
      let periodLabel = 'Lifetime';

      if (type === 'day') {
        filtered = allSessions.filter(s => s.date === selectedDate);
        periodLabel = `Date: ${format(new Date(selectedDate + 'T00:00:00'), 'dd/MM/yyyy')}`;
      } else if (type === 'month') {
        const start = new Date(selectedMonth + '-01T00:00:00');
        const end = endOfMonth(start);
        filtered = allSessions.filter(s => {
          const d = new Date(s.date + 'T00:00:00');
          return isWithinInterval(d, { start, end });
        });
        periodLabel = `Month: ${format(start, 'MMMM yyyy')}`;
      }

      filtered.sort((a, b) => a.date.localeCompare(b.date));

      const totalDuration = filtered.reduce((acc, s) => acc + s.duration, 0);
      const subjectMap: Record<string, { sessions: number, duration: number }> = {};
      filtered.forEach(s => {
        if (!subjectMap[s.subject]) subjectMap[s.subject] = { sessions: 0, duration: 0 };
        subjectMap[s.subject].sessions += 1;
        subjectMap[s.subject].duration += s.duration;
      });

      const subjectData = Object.keys(subjectMap).map(name => ({
        name,
        sessions: subjectMap[name].sessions,
        duration: subjectMap[name].duration,
        percentage: totalDuration > 0 ? (subjectMap[name].duration / totalDuration) * 100 : 0
      })).sort((a, b) => b.duration - a.duration);

      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      doc.setFillColor(63, 66, 241);
      doc.rect(0, 0, pageWidth, 55, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(28);
      doc.setFont("helvetica", "bold");
      doc.text("Digital Study Diary", pageWidth / 2, 28, { align: 'center' });
      doc.setFontSize(14);
      doc.text("Comprehensive Study History", pageWidth / 2, 40, { align: 'center' });

      doc.setTextColor(40, 44, 52);
      doc.setFontSize(11);
      doc.text(`UID: ${uid}`, 14, 70);
      doc.setTextColor(63, 66, 241);
      doc.text(`Period: ${periodLabel}`, 14, 78);
      
      autoTable(doc, {
        startY: 90,
        head: [['Subject Name', 'Sessions', 'Total Time', 'Percentage (%)']],
        body: subjectData.map(d => [d.name, d.sessions, formatDurationEng(d.duration), `${d.percentage.toFixed(1)}%`]),
        headStyles: { fillColor: [63, 66, 241] }
      });

      autoTable(doc, {
        startY: (doc as any).lastAutoTable.finalY + 15,
        head: [['#', 'Date', 'Subject', 'Topic', 'Duration']],
        body: filtered.map((s, i) => [i + 1, s.date, s.subject, s.topic, formatDurationEng(s.duration)]),
        headStyles: { fillColor: [63, 66, 241] }
      });

      doc.save(`Study_Report_${uid}_${Date.now()}.pdf`);
    } catch (err) {
      console.error(err);
      alert("Error generating report");
    } finally {
      setGenerating(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-10 animate-fadeIn">
      <div>
        <h1 className="text-3xl font-black text-white">রিপোর্ট জেনারেট করুন</h1>
        <p className="text-slate-500 mt-1">{targetUid ? `ইউজার (ID: ${targetUid}) এর রিপোর্ট ডাউনলোড করুন` : 'আপনার পড়াশোনার ইতিহাস আকর্ষণীয় পিডিএফ ফরম্যাটে ডাউনলোড করুন'}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-slate-800 shadow-xl flex flex-col hover:border-indigo-500/30 transition-all group">
          <Calendar size={26} className="text-indigo-400 mb-6" />
          <h3 className="text-xl font-black mb-2 text-white">দৈনিক রিপোর্ট</h3>
          <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 mb-6 text-white" />
          <button onClick={() => generateReport('day')} disabled={generating} className="bg-indigo-600 text-white py-4 rounded-xl font-black">ডাউনলোড PDF</button>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-slate-800 shadow-xl flex flex-col hover:border-purple-500/30 transition-all group">
          <Filter size={26} className="text-purple-400 mb-6" />
          <h3 className="text-xl font-black mb-2 text-white">মাসিক রিপোর্ট</h3>
          <input type="month" value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 mb-6 text-white" />
          <button onClick={() => generateReport('month')} disabled={generating} className="bg-purple-600 text-white py-4 rounded-xl font-black">ডাউনলোড PDF</button>
        </div>

        <div className="bg-slate-900 p-8 rounded-[2.5rem] border border-slate-800 shadow-xl flex flex-col hover:border-orange-500/30 transition-all group">
          <FileText size={26} className="text-orange-400 mb-6" />
          <h3 className="text-xl font-black mb-2 text-white">সম্পূর্ণ ডায়েরি</h3>
          <div className="mb-[116px]"></div>
          <button onClick={() => generateReport('full')} disabled={generating} className="bg-orange-600 text-white py-4 rounded-xl font-black">ডাউনলোড PDF</button>
        </div>
      </div>
    </div>
  );
};

export default Reports;
