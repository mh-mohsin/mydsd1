
import React, { useState } from 'react';
import { auth } from '../firebase';
import { createUserWithEmailAndPassword, updateProfile } from 'firebase/auth';
import { createUserProfile } from '../services/dbService';
import { Link, useNavigate } from 'react-router-dom';
import { BookOpen, UserPlus, Mail, Lock, User, Sparkles } from 'lucide-react';

const Signup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      await updateProfile(user, { displayName: name });
      await createUserProfile(user.uid, name, email);
      navigate('/');
    } catch (err: any) {
      setError("অ্যাকাউন্ট তৈরি করতে সমস্যা হয়েছে। আবার চেষ্টা করুন।");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 p-6">
      <div className="w-full max-w-md bg-slate-900 rounded-[2.5rem] shadow-2xl border border-slate-800 overflow-hidden animate-fadeIn relative">
        <div className="p-10 md:p-14 relative z-10">
          <div className="flex flex-col items-center mb-10">
            <div className="w-16 h-16 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-2xl shadow-indigo-600/30 mb-6">
              <BookOpen size={32} />
            </div>
            <h1 className="text-2xl font-black text-white text-center">অ্যাকাউন্ট তৈরি করুন</h1>
            <p className="text-slate-500 mt-2 font-medium">স্মার্ট লার্নিং কমিউনিটিতে যোগ দিন</p>
          </div>
          
          {error && (
            <div className="mb-8 p-4 bg-rose-500/10 text-rose-400 text-sm rounded-2xl border border-rose-500/20 text-center font-bold">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSignup} className="space-y-6">
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">আপনার নাম</label>
              <div className="relative group">
                <User className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-500 transition-colors" size={20} />
                <input required type="text" value={name} onChange={e => setName(e.target.value)} placeholder="জন ডো"
                  className="w-full pl-14 pr-6 py-4 rounded-2xl border border-slate-800 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">ইমেইল ঠিকানা</label>
              <div className="relative group">
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-500 transition-colors" size={20} />
                <input required type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="name@email.com"
                  className="w-full pl-14 pr-6 py-4 rounded-2xl border border-slate-800 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-black text-slate-500 uppercase tracking-widest mb-2 ml-1">পাসওয়ার্ড</label>
              <div className="relative group">
                <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600 group-focus-within:text-indigo-500 transition-colors" size={20} />
                <input required type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••"
                  className="w-full pl-14 pr-6 py-4 rounded-2xl border border-slate-800 bg-slate-950 text-white focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all"
                />
              </div>
            </div>
            
            <button disabled={loading} type="submit" 
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white py-5 rounded-2xl font-black text-lg shadow-2xl shadow-indigo-600/30 transition-all flex items-center justify-center gap-3 disabled:opacity-50 active:scale-95"
            >
              {loading ? "তৈরি হচ্ছে..." : <><UserPlus size={22} /> সাইন আপ</>}
            </button>
          </form>
          
          <p className="mt-10 text-center text-slate-500 font-bold">
            ইতিমধ্যেই অ্যাকাউন্ট আছে? <Link to="/login" className="text-indigo-400 hover:text-indigo-300 transition-colors">লগইন করুন</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Signup;
